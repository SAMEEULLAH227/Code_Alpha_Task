const folders = {
    galleryPics: ['../download (1).jpg', '../download (2).jpg', '../download (3).jpg','../download (4).jpg','../download (5).jpg','../download (6).jpg','../download (7).jpg','../download (8).jpg'],
    personalPics: ['../download (9).jpg', '../download (10).jpg', '../download (11).jpg','../download (12).jpg','../download.jpg','../images (1).jpg','../images (2).jpg','../images.jpg'],
    vacationPics: ['../images (2).jpg', '../download.jpg', '../download (1).jpg','../download (11).jpg','../download (10).jpg','../download (12).jpg','../download (2).jpg','../download (3).jpg',]
};

function viewFolder(folderName) {
    // Hide folder view and show image view
    document.getElementById('folderView').style.display = 'none';
    document.getElementById('imageView').style.display = 'block';

    // Set folder title
    document.getElementById('folderTitle').textContent = folderName.replace(/([A-Z])/g, ' $1').trim();

    // Get the corresponding images for the folder
    const images = folders[folderName];
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = ''; // Clear the gallery before adding new images

    // Display the images in the gallery
    images.forEach(image => {
        const imgElement = document.createElement('img');
        imgElement.src = image;
        imgElement.alt = 'Image';
        imgElement.onclick = () => openImage(image);
        gallery.appendChild(imgElement);
    });
}

function openImage(imageSrc) {
    const img = new Image();
    img.src = imageSrc;
    img.alt = 'Full Image';
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.appendChild(img);

    // Append the overlay image to the body
    document.body.appendChild(overlay);

    // Close the image on click
    overlay.onclick = () => document.body.removeChild(overlay);
}

function backToFolders() {
    document.getElementById('folderView').style.display = 'block';
    document.getElementById('imageView').style.display = 'none';
}
