const folders = {
    galleryPics: ['../App Gallery/pics/download (1).jpg', '../App Gallery/pics/download (2).jpg', '../App Gallery/pics/download (3).jpg','../App Gallery/pics/download (12).jpg','../App Gallery/pics/download (5).jpg','../App Gallery/pics/download (6).jpg','../App Gallery/pics/download (7).jpg','../App Gallery/pics/download (8).jpg'],
    personalPics: ['../App Gallery/pics/download (9).jpg', '../App Gallery/pics/download (10).jpg', '../App Gallery/pics/download (11).jpg','../App Gallery/pics/download (12).jpg','../App Gallery/pics/download.jpg','../App Gallery/pics/images (1).jpg','../App Gallery/pics/images (2).jpg','../App Gallery/pics/images.jpg'],
    vacationPics: ['../App Gallery/pics/images (2).jpg', '../App Gallery/pics/download.jpg', '../App Gallery/pics/download (1).jpg','../App Gallery/pics/download (11).jpg','../App Gallery/pics/download (10).jpg','../App Gallery/pics/download (12).jpg','../App Gallery/pics/download (2).jpg','../App Gallery/pics/download (3).jpg',]
};

function viewFolder(folderName) {
    // Hide folder view and show image view
    document.getElementById('folderView').style.display = 'none';
    document.getElementById('imageView').style.display = 'block';

    // Set folder title
    document.getElementById('folderTitle').textContent = folderName.replace(/([A-Z])/g, ' $1').trim();

    // Get the corresponding images for the folder
    const images = folders[folderName];
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = ''; // Clear the gallery before adding new images

    // Display the images in the gallery
    images.forEach(image => {
        const imgElement = document.createElement('img');
        imgElement.src = image;
        imgElement.alt = 'Image';
        imgElement.onclick = () => openImage(image);
        gallery.appendChild(imgElement);
    });
}

function openImage(imageSrc) {
    const img = new Image();
    img.src = imageSrc;
    img.alt = 'Full Image';
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.appendChild(img);

    // Append the overlay image to the body
    document.body.appendChild(overlay);

    // Close the image on click
    overlay.onclick = () => document.body.removeChild(overlay);
}

function backToFolders() {
    document.getElementById('folderView').style.display = 'block';
    document.getElementById('imageView').style.display = 'none';
}
