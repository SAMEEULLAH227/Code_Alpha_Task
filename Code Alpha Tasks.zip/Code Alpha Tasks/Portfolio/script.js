// Smooth Scroll Functionality
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Dark Mode Toggle
let isDarkMode = localStorage.getItem("theme") === "dark";

function toggleTheme() {
    if (isDarkMode) {
        document.body.style.backgroundColor = "#f4f4f4"; // Light mode background
        document.body.style.color = "#333"; // Light mode text color
        document.querySelector('header').style.backgroundColor = "#333"; // Light mode header background
        localStorage.setItem("theme", "light");
        document.querySelector('.theme-toggle button').textContent = "🌙"; // Change icon to moon (for light mode)
    } else {
        document.body.style.backgroundColor = "#333"; // Dark mode background
        document.body.style.color = "#f4f4f4"; // Dark mode text color
        document.querySelector('header').style.backgroundColor = "#111"; // Dark mode header background
        localStorage.setItem("theme", "dark");
        document.querySelector('.theme-toggle button').textContent = "🌞"; // Change icon to sun (for dark mode)
    }
    isDarkMode = !isDarkMode; // Toggle state
}

// Initialize theme on page load
if (isDarkMode) {
    toggleTheme(); // Apply dark theme if stored in localStorage
}

// Simple Contact Form Handling (for demo purposes)
document.getElementById("contact-form").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent form from submitting
    alert("Thank you for reaching out! I'll get back to you shortly.");
    // Here you could send form data to your backend via AJAX or fetch API if needed
});
