let currentInput = '';
let operator = null;
let previousInput = '';
let isResultDisplayed = false;

const pi = Math.PI;
const e = Math.E;

// Function to append number to the display
function appendNumber(number) {
    if (isResultDisplayed) {
        currentInput = ''; // Reset if result was displayed
        isResultDisplayed = false;
    }
    currentInput += number.toString();
    updateDisplay(currentInput);
}

// Function to delete the last character (backspace)
function backspace() {
    if (currentInput.length > 0) {
        currentInput = currentInput.slice(0, -1); // Remove last character
        updateDisplay(currentInput);
    }
}

// Function to handle operations
function selectOperation(op) {
    if (currentInput === '') return; // Ignore if no number entered
    if (previousInput !== '') {
        calculate(); // Automatically calculate if an operation was previously entered
    }
    operator = op;
    previousInput = currentInput;
    currentInput = '';
}

// Function for scientific operations (sin, cos, etc.)
function selectFunction(func) {
    if (currentInput === '' && func !== 'sqrt' && func !== 'factorial') return;
    
    let result;
    switch (func) {
        case 'sin':
            result = Math.sin(parseFloat(currentInput) * Math.PI / 180); // degrees to radians
            break;
        case 'cos':
            result = Math.cos(parseFloat(currentInput) * Math.PI / 180);
            break;
        case 'tan':
            result = Math.tan(parseFloat(currentInput) * Math.PI / 180);
            break;
        case 'sqrt':
            result = Math.sqrt(parseFloat(currentInput));
            break;
        case 'log':
            result = Math.log10(parseFloat(currentInput)); // Log base 10
            break;
        case 'ln':
            result = Math.log(parseFloat(currentInput)); // Natural Log
            break;
        case 'exp':
            result = Math.exp(parseFloat(currentInput)); // e^x
            break;
        case 'x^y':
            result = Math.pow(parseFloat(previousInput), parseFloat(currentInput));
            break;
        default:
            return;
    }

    currentInput = result.toString();
    updateDisplay(currentInput);
}

// Function to calculate the final result
function calculate() {
    if (operator === null || currentInput === '' || previousInput === '') return;
    
    let result;
    const prev = parseFloat(previousInput);
    const current = parseFloat(currentInput);

    switch (operator) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                result = "Error";
            } else {
                result = prev / current;
            }
            break;
        default:
            return;
    }

    currentInput = result.toString();
    operator = null;
    previousInput = '';
    isResultDisplayed = true;
    updateDisplay(currentInput);
}

// Function to update the display
function updateDisplay(value) {
    document.getElementById('display').value = value;
}

// Function to clear the display
function clearDisplay() {
    currentInput = '';
    operator = null;
    previousInput = '';
    isResultDisplayed = false;
    updateDisplay('');
}

// Function to append the value of Pi (π)
function appendPi() {
    currentInput += pi;
    updateDisplay(currentInput);
}

// Function to append the value of e
function appendE() {
    currentInput += e;
    updateDisplay(currentInput);
}
